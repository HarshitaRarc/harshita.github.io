# Ponkala Harshita Gayathri — Data Engineer Portfolio

A production-ready, enterprise-grade portfolio built with Next.js 14 (App Router),
React, TypeScript, Tailwind CSS, and Framer Motion. Every fact on the site —
roles, dates, metrics, technologies, certifications, education — is sourced
directly from the attached resume; nothing has been invented.

## Tech stack

- **Framework:** Next.js 14 (App Router), React 18, TypeScript (strict mode)
- **Styling:** Tailwind CSS, custom dark design tokens
- **Motion:** Framer Motion (scroll reveals, hover states, animated hero graphic)
- **Icons:** lucide-react
- **Fonts:** system font stack (no external font requests) — see note below

## Project structure

```
/app                Route segments, layout, metadata, sitemap, robots
/components
  /layout            Navbar, Footer
  /sections           Hero, About, Experience, Skills, Projects,
                       Certifications, Education, Resume CTA, Contact
  /ui                 Reusable primitives (Button, Badge, Container,
                       SectionHeading, RevealOnScroll, AnimatedCounter, ...)
/lib                 site-config.ts (editable site metadata), data.ts
                     (resume-sourced content), utils.ts
/public              Favicon, OG image, resume PDF
/types               Shared TypeScript interfaces
```

## Getting started

```bash
npm install
npm run dev
```

Visit `http://localhost:3000`.

## Editing content

All resume-sourced copy lives in **`lib/data.ts`** — experience, skills,
projects, certifications, and education are typed arrays, so adding or
editing an entry is a matter of editing that one file. Site-wide settings
(name, email, social links, resume filename, production domain) live in
**`lib/site-config.ts`**.

Two links in `lib/site-config.ts` are placeholders and should be updated
before launch:

- `linkedinUrl` — the resume's hyperlink resolves to a generic
  `linkedin.com` URL rather than a personal profile slug. Replace with the
  direct profile URL.
- `githubUrl` — no GitHub URL was present on the resume; replace with the
  real profile once available.

Also update `siteUrl` in `lib/site-config.ts` to the production domain —
it feeds metadata, Open Graph tags, and `sitemap.xml`.

## Contact form

The contact form (`components/sections/ContactForm.tsx`) performs full
client-side validation and success/error states, then falls back to opening
the visitor's email client with a pre-filled message (no backend is wired
up). To capture submissions server-side, replace the `handleSubmit` body
with a POST to your own API route or a service like Formspree/Resend.

## Production build

```bash
npm run build
npm run start
```

## Deployment

The project is ready to deploy on Vercel, Netlify, or any Node-compatible
host:

1. Push to a Git repository.
2. Import into Vercel (or your platform of choice) — no special
   configuration is required beyond the default Next.js build command
   (`next build`) and output.
3. Set `siteUrl` in `lib/site-config.ts` to your production domain before
   the final build so metadata and `sitemap.xml` resolve correctly.

## Optional: switch to Inter via next/font

The site currently ships with a system font stack (`tailwind.config.ts` →
`theme.extend.fontFamily`) so the production build never depends on
outbound network access to Google Fonts. To use self-hosted Inter /
JetBrains Mono instead:

```tsx
// app/layout.tsx
import { Inter, JetBrains_Mono } from "next/font/google";

const inter = Inter({ subsets: ["latin"], variable: "--font-inter" });
const jbMono = JetBrains_Mono({ subsets: ["latin"], variable: "--font-jbmono" });
```

Apply `${inter.variable} ${jbMono.variable}` to the `<html>` className and
point `fontFamily.sans` / `fontFamily.mono` in `tailwind.config.ts` at
`var(--font-inter)` / `var(--font-jbmono)`. This works out of the box on
Vercel and any environment with normal internet access.

## Assets to replace before launch

- `/public/og-image.svg` — placeholder Open Graph card. For maximum social
  preview compatibility, export a PNG/JPG version (1200×630) from this SVG
  or a design tool.
- `/public/favicon.svg` — placeholder mark; swap for a personal brand mark
  if desired.
- `/public/Ponkala_Harshita_Gayathri_Resume.pdf` — the resume served by the
  "Download Resume" buttons; replace whenever the resume is updated.

## Accessibility & performance notes

- Semantic landmarks (`header`, `main`, `footer`, `nav`) and a skip-to-content link.
- Keyboard-accessible navigation, tabs, and form controls with visible focus rings.
- Color palette checked for WCAG AA contrast on body text against the dark background.
- `prefers-reduced-motion` disables/shortens animations globally.
- Fonts loaded with `next/font` (self-hosted, no layout shift, no external
  runtime requests).
