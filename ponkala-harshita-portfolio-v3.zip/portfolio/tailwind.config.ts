import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: "class",
  content: [
    "./app/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        base: {
          950: "#05070a",
          900: "#0a0e14",
          800: "#0f141c",
          700: "#161c27",
          600: "#212938",
          500: "#2f3a4d",
        },
        accent: {
          DEFAULT: "#3ba7ff",
          soft: "#7fc8ff",
          dim: "#1c6fb0",
        },
        signal: {
          teal: "#2dd4bf",
          amber: "#f5a623",
        },
        ink: {
          DEFAULT: "#e6ecf5",
          muted: "#9aa7bb",
          // Lightened from an earlier #5c6a80 to clear WCAG AA (4.5:1) for
          // the small text it's used on (captions, timestamps, footer copy).
          faint: "#7c8aa3",
        },
      },
      fontFamily: {
        sans: [
          "Inter",
          "ui-sans-serif",
          "system-ui",
          "-apple-system",
          "Segoe UI",
          "Roboto",
          "Helvetica Neue",
          "Arial",
          "sans-serif",
        ],
        mono: [
          "ui-monospace",
          "SFMono-Regular",
          "Menlo",
          "Monaco",
          "Consolas",
          "Liberation Mono",
          "Courier New",
          "monospace",
        ],
      },
      maxWidth: {
        content: "1180px",
      },
      backgroundImage: {
        grid: "linear-gradient(to right, rgba(255,255,255,0.04) 1px, transparent 1px), linear-gradient(to bottom, rgba(255,255,255,0.04) 1px, transparent 1px)",
        "radial-fade": "radial-gradient(ellipse 80% 60% at 50% 0%, rgba(59,167,255,0.16), transparent 70%)",
      },
      backgroundSize: {
        grid: "44px 44px",
      },
      keyframes: {
        drift: {
          "0%, 100%": { transform: "translate3d(0,0,0)" },
          "50%": { transform: "translate3d(0,-14px,0)" },
        },
        pulseGlow: {
          "0%, 100%": { opacity: "0.5" },
          "50%": { opacity: "1" },
        },
        marquee: {
          "0%": { transform: "translateX(0)" },
          "100%": { transform: "translateX(-50%)" },
        },
        flowLine: {
          "0%": { strokeDashoffset: "240" },
          "100%": { strokeDashoffset: "0" },
        },
      },
      animation: {
        drift: "drift 7s ease-in-out infinite",
        pulseGlow: "pulseGlow 3.5s ease-in-out infinite",
        marquee: "marquee 28s linear infinite",
        flowLine: "flowLine 6s linear infinite",
      },
    },
  },
  plugins: [],
};

export default config;
