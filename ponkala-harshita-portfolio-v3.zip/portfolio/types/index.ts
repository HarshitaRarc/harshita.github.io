export interface NavLink {
  label: string;
  href: string;
}

export interface SocialLink {
  label: string;
  href: string;
  icon: "linkedin" | "github" | "mail" | "credly";
}

export interface HeroMetric {
  label: string;
  value: string;
  suffix?: string;
  description: string;
}

export interface ExperienceHighlight {
  title: string;
  challenge: string;
  solution: string;
  impact: string[];
  technologies: string[];
}

export interface ExperienceRole {
  id: string;
  company: string;
  role: string;
  location: string;
  startDate: string;
  endDate: string;
  summary: string;
  highlights: ExperienceHighlight[];
}

export interface SkillCategory {
  id: string;
  title: string;
  description: string;
  icon: "code" | "workflow" | "cloud" | "shield";
  skills: string[];
}

export interface Project {
  id: string;
  title: string;
  tagline: string;
  challenge: string;
  solution: string;
  architecture: string[];
  impact: string[];
  technologies: string[];
  icon: "warehouse" | "spark" | "suite" | "ai";
}

export interface Certification {
  id: string;
  title: string;
  issuer: string;
  description: string;
  credentialUrl?: string;
  issued?: string;
}

export interface EducationEntry {
  institution: string;
  degree: string;
  field: string;
  startDate: string;
  endDate: string;
  gpa?: string;
  coursework: string[];
}

export interface Publication {
  title: string;
  venue: string;
  url: string;
}
