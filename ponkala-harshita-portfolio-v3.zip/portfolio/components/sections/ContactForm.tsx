"use client";

import { FormEvent, useState } from "react";
import { AlertCircle, CheckCircle2, Loader2, Send } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { siteConfig } from "@/lib/site-config";

interface FormState {
  name: string;
  email: string;
  message: string;
}

interface FormErrors {
  name?: string;
  email?: string;
  message?: string;
}

const initialState: FormState = { name: "", email: "", message: "" };

const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function validate(values: FormState): FormErrors {
  const errors: FormErrors = {};
  if (!values.name.trim()) errors.name = "Please enter your name.";
  if (!values.email.trim()) {
    errors.email = "Please enter your email.";
  } else if (!emailPattern.test(values.email)) {
    errors.email = "Enter a valid email address.";
  }
  if (!values.message.trim()) {
    errors.message = "Let me know what you'd like to discuss.";
  } else if (values.message.trim().length < 12) {
    errors.message = "Please add a little more detail (12+ characters).";
  }
  return errors;
}

type Status = "idle" | "submitting" | "success" | "error";

export function ContactForm() {
  const [values, setValues] = useState<FormState>(initialState);
  const [errors, setErrors] = useState<FormErrors>({});
  const [status, setStatus] = useState<Status>("idle");

  const handleChange = (field: keyof FormState) => (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    setValues((prev) => ({ ...prev, [field]: e.target.value }));
  };

  const handleSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const validationErrors = validate(values);
    setErrors(validationErrors);

    if (Object.keys(validationErrors).length > 0) {
      setStatus("error");
      return;
    }

    setStatus("submitting");

    try {
      // NOTE: no backend endpoint is wired up yet. Replace this block with a
      // real submission — e.g. POST to /api/contact, Formspree, or a
      // serverless function — before deploying to production. As a fallback
      // this opens the visitor's mail client pre-filled with their message.
      await new Promise((resolve) => setTimeout(resolve, 700));
      const subject = encodeURIComponent(`Portfolio inquiry from ${values.name}`);
      const body = encodeURIComponent(`${values.message}\n\n— ${values.name} (${values.email})`);
      window.location.href = `mailto:${siteConfig.email}?subject=${subject}&body=${body}`;
      setStatus("success");
      setValues(initialState);
    } catch {
      setStatus("error");
    }
  };

  return (
    <form noValidate onSubmit={handleSubmit} className="space-y-5" aria-describedby="form-status">
      <div>
        <label htmlFor="name" className="text-sm font-medium text-ink">
          Name
        </label>
        <input
          id="name"
          name="name"
          type="text"
          autoComplete="name"
          value={values.name}
          onChange={handleChange("name")}
          aria-invalid={Boolean(errors.name)}
          aria-describedby={errors.name ? "name-error" : undefined}
          className="mt-2 w-full rounded-lg border border-white/12 bg-white/[0.03] px-4 py-3 text-sm text-ink placeholder:text-ink-faint focus-visible:border-accent/60"
          placeholder="Jane Doe"
        />
        {errors.name ? (
          <p id="name-error" role="alert" className="mt-1.5 text-xs text-red-400">
            {errors.name}
          </p>
        ) : null}
      </div>

      <div>
        <label htmlFor="email" className="text-sm font-medium text-ink">
          Email
        </label>
        <input
          id="email"
          name="email"
          type="email"
          autoComplete="email"
          value={values.email}
          onChange={handleChange("email")}
          aria-invalid={Boolean(errors.email)}
          aria-describedby={errors.email ? "email-error" : undefined}
          className="mt-2 w-full rounded-lg border border-white/12 bg-white/[0.03] px-4 py-3 text-sm text-ink placeholder:text-ink-faint focus-visible:border-accent/60"
          placeholder="jane@company.com"
        />
        {errors.email ? (
          <p id="email-error" role="alert" className="mt-1.5 text-xs text-red-400">
            {errors.email}
          </p>
        ) : null}
      </div>

      <div>
        <label htmlFor="message" className="text-sm font-medium text-ink">
          Message
        </label>
        <textarea
          id="message"
          name="message"
          rows={5}
          value={values.message}
          onChange={handleChange("message")}
          aria-invalid={Boolean(errors.message)}
          aria-describedby={errors.message ? "message-error" : undefined}
          className="mt-2 w-full resize-none rounded-lg border border-white/12 bg-white/[0.03] px-4 py-3 text-sm text-ink placeholder:text-ink-faint focus-visible:border-accent/60"
          placeholder="Tell me a bit about the role or project you have in mind."
        />
        {errors.message ? (
          <p id="message-error" role="alert" className="mt-1.5 text-xs text-red-400">
            {errors.message}
          </p>
        ) : null}
      </div>

      <Button
        type="submit"
        disabled={status === "submitting"}
        className="w-full sm:w-auto"
        icon={
          status === "submitting" ? (
            <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
          ) : (
            <Send className="h-4 w-4" aria-hidden="true" />
          )
        }
      >
        {status === "submitting" ? "Sending..." : "Send Message"}
      </Button>

      <div id="form-status" aria-live="polite">
        {status === "success" ? (
          <p className="flex items-center gap-2 text-sm text-teal-400">
            <CheckCircle2 className="h-4 w-4" aria-hidden="true" />
            Your email client should now be open with your message ready to send.
          </p>
        ) : null}
        {status === "error" && Object.keys(errors).length === 0 ? (
          <p className="flex items-center gap-2 text-sm text-red-400">
            <AlertCircle className="h-4 w-4" aria-hidden="true" />
            Something went wrong. Please try again or email directly.
          </p>
        ) : null}
      </div>
    </form>
  );
}
