import { Container } from "@/components/ui/Container";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { RevealOnScroll } from "@/components/ui/RevealOnScroll";
import { ExperienceCard } from "@/components/sections/ExperienceCard";
import { experience } from "@/lib/data";

export function Experience() {
  return (
    <section id="experience" className="relative border-b border-white/5 py-24 sm:py-28">
      <Container>
        <SectionHeading
          eyebrow="Experience"
          title="Engineering case studies, not resume bullets"
          description="Every role below is framed the way a hiring manager evaluates it: the business problem, the engineering solution, and the measured outcome."
        />

        <div className="mt-14 space-y-8">
          {experience.map((role, i) => (
            <RevealOnScroll key={role.id} delay={0.08 * i}>
              <ExperienceCard role={role} />
            </RevealOnScroll>
          ))}
        </div>
      </Container>
    </section>
  );
}
