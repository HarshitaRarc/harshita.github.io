"use client";

import { motion } from "framer-motion";
import { ArrowRight, Download, MapPin, Sparkles } from "lucide-react";
import { Container } from "@/components/ui/Container";
import { ButtonLink } from "@/components/ui/Button";
import { GridBackground } from "@/components/ui/GridBackground";
import { AnimatedCounter } from "@/components/ui/AnimatedCounter";
import { HeroVisual } from "@/components/sections/HeroVisual";
import { heroMetrics } from "@/lib/data";
import { siteConfig } from "@/lib/site-config";

export function Hero() {
  return (
    <section
      id="home"
      className="relative overflow-hidden border-b border-white/5 pb-20 pt-32 sm:pt-40"
    >
      <GridBackground />
      <div
        aria-hidden="true"
        className="absolute -top-40 left-1/2 h-[420px] w-[820px] -translate-x-1/2 rounded-full bg-accent/10 blur-[120px]"
      />

      <Container className="relative grid items-center gap-16 lg:grid-cols-[1.05fr_0.95fr]">
        <div>
          <motion.div
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.03] px-3 py-1.5 text-xs font-medium text-ink-muted"
          >
            <Sparkles className="h-3.5 w-3.5 text-accent" aria-hidden="true" />
            Enterprise Data Engineering &middot; Fidelity Investments
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.65, delay: 0.08 }}
            className="mt-6 text-balance text-4xl font-semibold tracking-tight text-ink sm:text-5xl lg:text-[3.4rem] lg:leading-[1.08]"
          >
            {siteConfig.headline}
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.65, delay: 0.16 }}
            className="mt-6 max-w-xl text-lg leading-relaxed text-ink-muted"
          >
            {siteConfig.tagline} Currently architecting production data platforms at{" "}
            <span className="text-ink">Fidelity Investments</span>.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.65, delay: 0.24 }}
            className="mt-4 flex items-center gap-2 text-sm text-ink-faint"
          >
            <MapPin className="h-4 w-4" aria-hidden="true" />
            {siteConfig.location}
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.65, delay: 0.32 }}
            className="mt-9 flex flex-wrap items-center gap-3"
          >
            <ButtonLink href="#projects" icon={<ArrowRight className="h-4 w-4" aria-hidden="true" />}>
              View Projects
            </ButtonLink>
            <ButtonLink
              href={`/${siteConfig.resumeFileName}`}
              variant="secondary"
              external
              download={siteConfig.resumeFileName}
              icon={<Download className="h-4 w-4" aria-hidden="true" />}
            >
              Download Resume
            </ButtonLink>
            <ButtonLink href="#contact" variant="ghost">
              Contact Me
            </ButtonLink>
          </motion.div>

          <motion.dl
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.65, delay: 0.4 }}
            className="mt-14 grid grid-cols-2 gap-6 sm:grid-cols-4"
          >
            {heroMetrics.map((metric) => (
              <div key={metric.label} className="border-l border-white/10 pl-4">
                <dt className="sr-only">{metric.label}</dt>
                <dd className="font-mono text-2xl font-semibold text-ink sm:text-3xl">
                  <AnimatedCounter value={metric.value} />
                </dd>
                <p className="mt-1 text-xs leading-snug text-ink-faint">{metric.label}</p>
              </div>
            ))}
          </motion.dl>
        </div>

        <motion.div
          initial={{ opacity: 0, scale: 0.94 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="relative"
        >
          <HeroVisual />
        </motion.div>
      </Container>
    </section>
  );
}
