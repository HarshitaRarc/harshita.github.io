import { BookOpen, ExternalLink, FileText, GraduationCap } from "lucide-react";
import { Container } from "@/components/ui/Container";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { RevealOnScroll } from "@/components/ui/RevealOnScroll";
import { Badge } from "@/components/ui/Badge";
import { education, publication } from "@/lib/data";

export function Education() {
  const entry = education[0];
  if (!entry) return null;

  return (
    <section id="education" className="relative border-b border-white/5 py-24 sm:py-28">
      <Container>
        <SectionHeading eyebrow="Education" title="Academic foundation" />

        <div className="mt-14 grid gap-6 lg:grid-cols-2">
          <RevealOnScroll>
            <div className="gradient-border h-full rounded-2xl border border-white/8 bg-base-800/50 p-7 transition-all duration-200 hover:-translate-y-1 hover:border-accent/25 hover:shadow-lg hover:shadow-black/20">
              <span className="flex h-11 w-11 items-center justify-center rounded-xl border border-white/10 bg-white/[0.04] text-accent">
                <GraduationCap className="h-5 w-5" aria-hidden="true" />
              </span>
              <h3 className="mt-4 text-lg font-semibold text-ink">
                {entry.degree}, {entry.field}
              </h3>
              <p className="mt-1 text-sm text-ink-muted">{entry.institution}</p>
              <div className="mt-3 flex flex-wrap items-center gap-3 text-xs text-ink-faint">
                <span className="font-mono">
                  {entry.startDate} — {entry.endDate}
                </span>
                {entry.gpa ? (
                  <span className="rounded-full border border-white/10 bg-white/[0.03] px-2.5 py-1">
                    {entry.gpa}
                  </span>
                ) : null}
              </div>

              <div className="mt-6">
                <div className="flex items-center gap-2 text-ink-faint">
                  <BookOpen className="h-4 w-4" aria-hidden="true" />
                  <span className="text-xs font-semibold uppercase tracking-wide">
                    Relevant coursework
                  </span>
                </div>
                <div className="mt-3 flex flex-wrap gap-2">
                  {entry.coursework.map((course) => (
                    <Badge key={course}>{course}</Badge>
                  ))}
                </div>
              </div>
            </div>
          </RevealOnScroll>

          <RevealOnScroll delay={0.1}>
            <div className="gradient-border flex h-full flex-col justify-center rounded-2xl border border-white/8 bg-base-800/50 p-7 transition-all duration-200 hover:-translate-y-1 hover:border-accent/25 hover:shadow-lg hover:shadow-black/20">
              <span className="flex h-11 w-11 items-center justify-center rounded-xl border border-white/10 bg-white/[0.04] text-accent">
                <FileText className="h-5 w-5" aria-hidden="true" />
              </span>
              <p className="mt-4 text-xs font-semibold uppercase tracking-wide text-ink-faint">
                Research &amp; Publications
              </p>
              <h3 className="mt-2 text-base font-semibold leading-snug text-ink">
                {publication.title}
              </h3>
              <p className="mt-1 text-sm text-ink-muted">{publication.venue}</p>
              <a
                href={publication.url}
                target="_blank"
                rel="noopener noreferrer"
                className="mt-4 inline-flex w-fit items-center gap-1.5 text-sm font-medium text-accent-soft hover:text-accent"
              >
                View publication
                <ExternalLink className="h-3.5 w-3.5" aria-hidden="true" />
              </a>
            </div>
          </RevealOnScroll>
        </div>
      </Container>
    </section>
  );
}
