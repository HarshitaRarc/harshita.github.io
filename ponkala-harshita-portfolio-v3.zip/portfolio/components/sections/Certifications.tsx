import { Award, ExternalLink, Plus } from "lucide-react";
import { Container } from "@/components/ui/Container";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { RevealOnScroll } from "@/components/ui/RevealOnScroll";
import { certifications } from "@/lib/data";

export function Certifications() {
  return (
    <section id="certifications" className="relative border-b border-white/5 py-24 sm:py-28">
      <Container>
        <SectionHeading
          eyebrow="Certifications"
          title="Verified cloud credentials"
          description="Professional certifications validating hands-on cloud architecture expertise."
        />

        <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {certifications.map((cert, i) => (
            <RevealOnScroll key={cert.id} delay={0.06 * i}>
              <div className="gradient-border h-full rounded-2xl border border-white/8 bg-base-800/50 p-6 transition-all duration-200 hover:-translate-y-1 hover:border-accent/25 hover:shadow-lg hover:shadow-black/20">
                <span className="flex h-11 w-11 items-center justify-center rounded-xl border border-white/10 bg-white/[0.04] text-accent">
                  <Award className="h-5 w-5" aria-hidden="true" />
                </span>
                <h3 className="mt-4 text-base font-semibold text-ink">{cert.title}</h3>
                <p className="mt-1 text-sm text-ink-faint">{cert.issuer}</p>
                <p className="mt-3 text-sm leading-relaxed text-ink-muted">{cert.description}</p>
                {cert.credentialUrl ? (
                  <a
                    href={cert.credentialUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="mt-4 inline-flex items-center gap-1.5 text-sm font-medium text-accent-soft hover:text-accent"
                  >
                    View credential
                    <ExternalLink className="h-3.5 w-3.5" aria-hidden="true" />
                  </a>
                ) : null}
              </div>
            </RevealOnScroll>
          ))}

          <RevealOnScroll delay={0.06 * certifications.length}>
            <div className="flex h-full flex-col items-center justify-center rounded-2xl border border-dashed border-white/12 bg-white/[0.015] p-6 text-center">
              <span className="flex h-11 w-11 items-center justify-center rounded-xl border border-white/10 bg-white/[0.03] text-ink-faint">
                <Plus className="h-5 w-5" aria-hidden="true" />
              </span>
              <p className="mt-4 text-sm font-medium text-ink-muted">More on the way</p>
              <p className="mt-1 text-xs leading-relaxed text-ink-faint">
                Reserved for upcoming certifications such as SnowPro Core or a Databricks
                Data Engineer credential.
              </p>
            </div>
          </RevealOnScroll>
        </div>
      </Container>
    </section>
  );
}
