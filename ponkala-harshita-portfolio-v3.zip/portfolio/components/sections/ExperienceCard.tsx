"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Briefcase, CheckCircle2, MapPin, Target, Wrench } from "lucide-react";
import type { ExperienceRole } from "@/types";
import { Badge } from "@/components/ui/Badge";
import { cn } from "@/lib/utils";

export function ExperienceCard({ role }: { role: ExperienceRole }) {
  const [active, setActive] = useState(0);
  const highlight = role.highlights[active];

  return (
    <div className="gradient-border rounded-2xl border border-white/8 bg-base-800/50 p-6 transition-colors duration-200 hover:border-white/15 sm:p-8">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <div className="flex items-center gap-2 text-accent-soft">
            <Briefcase className="h-4 w-4" aria-hidden="true" />
            <span className="text-sm font-medium">{role.role}</span>
          </div>
          <h3 className="mt-1 text-xl font-semibold text-ink">{role.company}</h3>
          <div className="mt-1.5 flex items-center gap-1.5 text-sm text-ink-faint">
            <MapPin className="h-3.5 w-3.5" aria-hidden="true" />
            {role.location}
          </div>
        </div>
        <span className="inline-flex w-fit items-center rounded-full border border-white/10 bg-white/[0.03] px-3 py-1 font-mono text-xs text-ink-muted">
          {role.startDate} — {role.endDate}
        </span>
      </div>

      <p className="mt-5 max-w-3xl text-sm leading-relaxed text-ink-muted">{role.summary}</p>

      {role.highlights.length > 1 ? (
        <div
          role="tablist"
          aria-label={`${role.company} engineering case studies`}
          className="mt-7 flex flex-wrap gap-2 border-b border-white/8 pb-4"
        >
          {role.highlights.map((h, i) => (
            <button
              key={h.title}
              role="tab"
              type="button"
              aria-selected={active === i}
              onClick={() => setActive(i)}
              className={cn(
                "rounded-lg border px-3.5 py-2 text-left text-xs font-medium transition-all active:scale-[0.97]",
                active === i
                  ? "border-accent/50 bg-accent/10 text-accent-soft"
                  : "border-white/10 bg-white/[0.02] text-ink-faint hover:text-ink-muted"
              )}
            >
              {h.title}
            </button>
          ))}
        </div>
      ) : (
        <div className="mt-7 border-b border-white/8 pb-4">
          <h4 className="text-sm font-semibold text-ink">{highlight?.title}</h4>
        </div>
      )}

      <AnimatePresence mode="wait">
        <motion.div
          key={highlight?.title}
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -8 }}
          transition={{ duration: 0.3 }}
          className="mt-6 grid gap-6 md:grid-cols-2"
        >
          <div className="space-y-5">
            <div>
              <div className="flex items-center gap-2 text-amber-400">
                <Target className="h-4 w-4" aria-hidden="true" />
                <span className="text-xs font-semibold uppercase tracking-wide">
                  Business challenge
                </span>
              </div>
              <p className="mt-2 text-sm leading-relaxed text-ink-muted">{highlight?.challenge}</p>
            </div>
            <div>
              <div className="flex items-center gap-2 text-accent">
                <Wrench className="h-4 w-4" aria-hidden="true" />
                <span className="text-xs font-semibold uppercase tracking-wide">Solution</span>
              </div>
              <p className="mt-2 text-sm leading-relaxed text-ink-muted">{highlight?.solution}</p>
            </div>
          </div>

          <div>
            <div className="flex items-center gap-2 text-teal-400">
              <CheckCircle2 className="h-4 w-4" aria-hidden="true" />
              <span className="text-xs font-semibold uppercase tracking-wide">Business impact</span>
            </div>
            <ul className="mt-2 space-y-2">
              {highlight?.impact.map((item) => (
                <li key={item} className="flex gap-2 text-sm leading-relaxed text-ink-muted">
                  <span className="mt-2 h-1 w-1 shrink-0 rounded-full bg-teal-400" aria-hidden="true" />
                  {item}
                </li>
              ))}
            </ul>
            <div className="mt-5 flex flex-wrap gap-2">
              {highlight?.technologies.map((tech) => (
                <Badge key={tech}>{tech}</Badge>
              ))}
            </div>
          </div>
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
