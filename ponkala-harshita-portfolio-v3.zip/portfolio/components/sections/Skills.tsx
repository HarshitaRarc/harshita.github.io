"use client";

import { motion } from "framer-motion";
import { Cloud, Code2, ShieldCheck, Workflow, type LucideIcon } from "lucide-react";
import { Container } from "@/components/ui/Container";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { RevealOnScroll } from "@/components/ui/RevealOnScroll";
import { skillCategories } from "@/lib/data";

const iconMap: Record<string, LucideIcon> = {
  code: Code2,
  workflow: Workflow,
  cloud: Cloud,
  shield: ShieldCheck,
};

export function Skills() {
  return (
    <section id="skills" className="relative border-b border-white/5 py-24 sm:py-28">
      <Container>
        <SectionHeading
          eyebrow="Skills"
          title="A production-grade toolkit for enterprise data platforms"
          description="Organized the way the work actually breaks down — from query languages to cloud infrastructure to the governance layer that keeps it trustworthy."
        />

        <div className="mt-14 grid gap-5 md:grid-cols-2">
          {skillCategories.map((category, i) => {
            const Icon = iconMap[category.icon];
            return (
              <RevealOnScroll key={category.id} delay={0.06 * i}>
                <div className="group h-full rounded-2xl border border-white/8 bg-base-800/50 p-6 transition-all duration-200 hover:-translate-y-1 hover:border-accent/30 hover:shadow-lg hover:shadow-black/20 sm:p-7">
                  <div className="flex items-start gap-4">
                    <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border border-white/10 bg-white/[0.04] text-accent transition-transform group-hover:scale-105">
                      {Icon ? <Icon className="h-5 w-5" aria-hidden="true" /> : null}
                    </span>
                    <div>
                      <h3 className="text-base font-semibold text-ink">{category.title}</h3>
                      <p className="mt-1 text-sm leading-relaxed text-ink-muted">
                        {category.description}
                      </p>
                    </div>
                  </div>

                  <ul className="mt-5 flex flex-wrap gap-2">
                    {category.skills.map((skill, si) => (
                      <motion.li
                        key={skill}
                        initial={{ opacity: 0, y: 6 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        viewport={{ once: true }}
                        transition={{ duration: 0.35, delay: si * 0.04 }}
                        whileHover={{ y: -2 }}
                        className="rounded-lg border border-white/10 bg-white/[0.03] px-3 py-1.5 text-xs font-medium text-ink-muted transition-colors hover:border-accent/40 hover:bg-accent/[0.06] hover:text-ink"
                      >
                        {skill}
                      </motion.li>
                    ))}
                  </ul>
                </div>
              </RevealOnScroll>
            );
          })}
        </div>
      </Container>
    </section>
  );
}
