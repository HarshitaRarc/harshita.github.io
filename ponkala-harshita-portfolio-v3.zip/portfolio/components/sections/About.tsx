import { Container } from "@/components/ui/Container";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { RevealOnScroll } from "@/components/ui/RevealOnScroll";
import { Database, GitBranch, ShieldCheck, Users } from "lucide-react";

const pillars = [
  {
    icon: Database,
    title: "Enterprise data warehousing",
    description:
      "Owns core warehouse subject areas end-to-end, re-architecting SCD-based dimensional models to keep historical data accurate and reportable.",
  },
  {
    icon: GitBranch,
    title: "Cloud & migration engineering",
    description:
      "Builds Spark-based validation frameworks that certify data integrity across large-scale Oracle-to-Snowflake migrations, 2TB+ at a time.",
  },
  {
    icon: ShieldCheck,
    title: "Data quality & AI/ML foundations",
    description:
      "Designs automated data-quality checks and triage tooling that keep fraud/risk scoring models and downstream analytics production-ready.",
  },
  {
    icon: Users,
    title: "Cross-functional ownership",
    description:
      "Partners directly with senior engineers, stakeholders, and data science teams to turn ambiguous requirements into long-term data models.",
  },
];

export function About() {
  return (
    <section id="about" className="relative border-b border-white/5 py-24 sm:py-28">
      <Container>
        <SectionHeading
          eyebrow="About"
          title="A Data Engineer who owns the platform, not just the pipeline"
          description="3+ years architecting and building scalable, production-grade data pipelines and enterprise data warehouse solutions — writing complex SQL and Python against large-scale infrastructure (2TB+, billions of records)."
        />

        <RevealOnScroll delay={0.1}>
          <p className="mt-8 max-w-3xl text-base leading-relaxed text-ink-muted">
            Skilled in owning subject areas end-to-end — from ambiguous requirements to
            long-term data models — building AI/ML-ready data foundations, and delivering
            complex data projects from conception to production. Partners closely with senior
            engineers, stakeholders, and data science teams to drive data quality, reliability,
            and efficiency across the stack at Fidelity Investments.
          </p>
        </RevealOnScroll>

        <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {pillars.map((pillar, i) => (
            <RevealOnScroll key={pillar.title} delay={0.05 * i}>
              <div className="gradient-border h-full rounded-2xl border border-white/8 bg-base-800/60 p-6 transition-all duration-200 hover:-translate-y-1 hover:bg-base-800 hover:shadow-lg hover:shadow-black/20">
                <span className="flex h-10 w-10 items-center justify-center rounded-lg border border-white/10 bg-white/[0.04] text-accent">
                  <pillar.icon className="h-5 w-5" aria-hidden="true" />
                </span>
                <h3 className="mt-4 text-sm font-semibold text-ink">{pillar.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-ink-muted">{pillar.description}</p>
              </div>
            </RevealOnScroll>
          ))}
        </div>
      </Container>
    </section>
  );
}
