"use client";

import { motion } from "framer-motion";

/**
 * Subtle, non-distracting network / data-flow motif for the hero section.
 * Pure SVG + CSS animation, no external assets, respects reduced-motion
 * via globals.css animation-duration override.
 */
export function HeroVisual() {
  const nodes = [
    { x: 60, y: 70 },
    { x: 210, y: 40 },
    { x: 340, y: 110 },
    { x: 120, y: 190 },
    { x: 280, y: 230 },
    { x: 400, y: 60 },
    { x: 400, y: 210 },
  ];

  const edges: [number, number][] = [
    [0, 1],
    [1, 2],
    [1, 3],
    [3, 4],
    [2, 5],
    [4, 6],
    [2, 6],
  ];

  return (
    <div className="relative mx-auto aspect-square w-full max-w-[480px]" aria-hidden="true">
      <div className="absolute inset-0 rounded-full bg-radial-fade blur-2xl" />
      <svg viewBox="0 0 460 280" className="relative h-full w-full" fill="none">
        <defs>
          <linearGradient id="edgeGradient" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#3ba7ff" stopOpacity="0.7" />
            <stop offset="100%" stopColor="#2dd4bf" stopOpacity="0.15" />
          </linearGradient>
          <radialGradient id="nodeGlow">
            <stop offset="0%" stopColor="#7fc8ff" stopOpacity="0.9" />
            <stop offset="100%" stopColor="#3ba7ff" stopOpacity="0" />
          </radialGradient>
        </defs>

        {edges.map(([a, b], i) => {
          const start = nodes[a];
          const end = nodes[b];
          if (!start || !end) return null;
          return (
            <g key={`${a}-${b}`}>
              <line
                x1={start.x}
                y1={start.y}
                x2={end.x}
                y2={end.y}
                stroke="url(#edgeGradient)"
                strokeWidth={1}
              />
              <motion.circle
                r={2.2}
                fill="#7fc8ff"
                initial={{ opacity: 0 }}
                animate={{
                  cx: [start.x, end.x],
                  cy: [start.y, end.y],
                  opacity: [0, 1, 0],
                }}
                transition={{
                  duration: 3.5,
                  repeat: Infinity,
                  delay: i * 0.6,
                  ease: "easeInOut",
                }}
              />
            </g>
          );
        })}

        {nodes.map((node, i) => (
          <g key={i}>
            <circle cx={node.x} cy={node.y} r={22} fill="url(#nodeGlow)" opacity={0.5} />
            <circle
              cx={node.x}
              cy={node.y}
              r={i === 2 ? 7 : 4.5}
              fill="#0f141c"
              stroke="#3ba7ff"
              strokeWidth={1.5}
            />
          </g>
        ))}
      </svg>
    </div>
  );
}
