"use client";

import { useState } from "react";
import { Check, Copy, Github, Linkedin, Mail, MapPin } from "lucide-react";
import { siteConfig } from "@/lib/site-config";

const channels = [
  { icon: Linkedin, label: "LinkedIn", value: "Connect on LinkedIn", href: siteConfig.linkedinUrl },
  { icon: Github, label: "GitHub", value: "View on GitHub", href: siteConfig.githubUrl },
];

export function ContactChannels() {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(siteConfig.email);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2000);
    } catch {
      // Clipboard API unavailable — the mailto link below still works.
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2 text-sm text-ink-muted">
        <MapPin className="h-4 w-4 text-ink-faint" aria-hidden="true" />
        {siteConfig.location}
      </div>

      <div className="flex items-center gap-2 rounded-xl border border-white/8 bg-base-800/50 p-4 transition-colors hover:border-accent/30 hover:bg-base-800">
        <a
          href={`mailto:${siteConfig.email}`}
          className="flex flex-1 items-center gap-4"
        >
          <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border border-white/10 bg-white/[0.04] text-accent">
            <Mail className="h-4 w-4" aria-hidden="true" />
          </span>
          <span>
            <span className="block text-xs text-ink-faint">Email</span>
            <span className="block text-sm font-medium text-ink">{siteConfig.email}</span>
          </span>
        </a>
        <button
          type="button"
          onClick={handleCopy}
          aria-label={copied ? "Email copied" : "Copy email address"}
          className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-white/10 bg-white/[0.03] text-ink-faint transition-colors hover:border-accent/40 hover:text-accent"
        >
          {copied ? (
            <Check className="h-4 w-4 text-teal-400" aria-hidden="true" />
          ) : (
            <Copy className="h-4 w-4" aria-hidden="true" />
          )}
        </button>
      </div>

      {channels.map((channel) => (
        <a
          key={channel.label}
          href={channel.href}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-4 rounded-xl border border-white/8 bg-base-800/50 p-4 transition-colors hover:border-accent/30 hover:bg-base-800"
        >
          <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border border-white/10 bg-white/[0.04] text-accent">
            <channel.icon className="h-4 w-4" aria-hidden="true" />
          </span>
          <span>
            <span className="block text-xs text-ink-faint">{channel.label}</span>
            <span className="block text-sm font-medium text-ink">{channel.value}</span>
          </span>
        </a>
      ))}
    </div>
  );
}
