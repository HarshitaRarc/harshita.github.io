import { Container } from "@/components/ui/Container";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { RevealOnScroll } from "@/components/ui/RevealOnScroll";
import { Badge } from "@/components/ui/Badge";
import { projects } from "@/lib/data";
import { BrainCircuit, Layers, Sparkles, TrendingUp, Warehouse, type LucideIcon } from "lucide-react";

const iconMap: Record<string, LucideIcon> = {
  warehouse: Warehouse,
  spark: Sparkles,
  suite: Layers,
  ai: BrainCircuit,
};

export function Projects() {
  return (
    <section id="projects" className="relative border-b border-white/5 py-24 sm:py-28">
      <Container>
        <SectionHeading
          eyebrow="Featured Projects"
          title="Platform work that shipped to production"
          description="Case studies from Fidelity Investments, framed as an engineer would present them: the problem, the architecture, and the measurable outcome."
        />

        <div className="mt-14 grid gap-6 lg:grid-cols-3">
          {projects.map((project, i) => {
            const Icon = iconMap[project.icon];
            return (
              <RevealOnScroll key={project.id} delay={0.08 * i}>
                <article className="gradient-border flex h-full flex-col rounded-2xl border border-white/8 bg-base-800/50 p-6 transition-all duration-200 hover:-translate-y-1 hover:border-accent/25 hover:shadow-lg hover:shadow-black/20 sm:p-7">
                  <span className="flex h-11 w-11 items-center justify-center rounded-xl border border-white/10 bg-white/[0.04] text-accent">
                    {Icon ? <Icon className="h-5 w-5" aria-hidden="true" /> : null}
                  </span>

                  <h3 className="mt-5 text-lg font-semibold text-ink">{project.title}</h3>
                  <p className="mt-1 text-sm font-medium text-accent-soft">{project.tagline}</p>

                  <div className="mt-5 space-y-4 text-sm leading-relaxed text-ink-muted">
                    <div>
                      <p className="text-xs font-semibold uppercase tracking-wide text-ink-faint">
                        Challenge
                      </p>
                      <p className="mt-1.5">{project.challenge}</p>
                    </div>
                    <div>
                      <p className="text-xs font-semibold uppercase tracking-wide text-ink-faint">
                        Solution
                      </p>
                      <p className="mt-1.5">{project.solution}</p>
                    </div>
                    <div>
                      <p className="text-xs font-semibold uppercase tracking-wide text-ink-faint">
                        Architecture
                      </p>
                      <ul className="mt-1.5 space-y-1.5">
                        {project.architecture.map((item) => (
                          <li key={item} className="flex gap-2">
                            <span
                              className="mt-2 h-1 w-1 shrink-0 rounded-full bg-accent"
                              aria-hidden="true"
                            />
                            {item}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  <div className="mt-6 space-y-2 rounded-xl border border-teal-500/15 bg-teal-500/[0.04] p-4">
                    {project.impact.map((item) => (
                      <div key={item} className="flex items-start gap-2 text-sm text-ink">
                        <TrendingUp className="mt-0.5 h-3.5 w-3.5 shrink-0 text-teal-400" aria-hidden="true" />
                        {item}
                      </div>
                    ))}
                  </div>

                  <div className="mt-6 flex flex-wrap gap-2 pt-1">
                    {project.technologies.map((tech) => (
                      <Badge key={tech}>{tech}</Badge>
                    ))}
                  </div>
                </article>
              </RevealOnScroll>
            );
          })}
        </div>
      </Container>
    </section>
  );
}
