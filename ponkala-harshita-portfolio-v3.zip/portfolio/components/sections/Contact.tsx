import { Container } from "@/components/ui/Container";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { RevealOnScroll } from "@/components/ui/RevealOnScroll";
import { ContactForm } from "@/components/sections/ContactForm";
import { ContactChannels } from "@/components/sections/ContactChannels";

export function Contact() {
  return (
    <section id="contact" className="relative py-24 sm:py-28">
      <Container>
        <SectionHeading
          eyebrow="Contact"
          title="Let's build something reliable"
          description="Open to Data Engineering roles and collaborations focused on cloud-native data platforms. Reach out below or connect directly."
        />

        <div className="mt-14 grid gap-8 lg:grid-cols-[0.85fr_1.15fr]">
          <RevealOnScroll>
            <ContactChannels />
          </RevealOnScroll>

          <RevealOnScroll delay={0.1}>
            <div className="gradient-border rounded-2xl border border-white/8 bg-base-800/50 p-6 sm:p-8">
              <ContactForm />
            </div>
          </RevealOnScroll>
        </div>
      </Container>
    </section>
  );
}
