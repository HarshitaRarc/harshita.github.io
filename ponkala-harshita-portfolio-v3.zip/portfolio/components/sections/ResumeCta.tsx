import { Download, FileText } from "lucide-react";
import { Container } from "@/components/ui/Container";
import { ButtonLink } from "@/components/ui/Button";
import { GridBackground } from "@/components/ui/GridBackground";
import { RevealOnScroll } from "@/components/ui/RevealOnScroll";
import { siteConfig } from "@/lib/site-config";

export function ResumeCta() {
  return (
    <section id="resume" className="relative overflow-hidden border-b border-white/5 py-24 sm:py-28">
      <GridBackground />
      <div
        aria-hidden="true"
        className="absolute left-1/2 top-1/2 h-[360px] w-[720px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-accent/10 blur-[110px]"
      />
      <Container className="relative">
        <RevealOnScroll>
          <div className="mx-auto flex max-w-2xl flex-col items-center rounded-2xl border border-white/10 bg-base-800/60 px-6 py-14 text-center sm:px-14">
            <span className="flex h-12 w-12 items-center justify-center rounded-xl border border-white/10 bg-white/[0.04] text-accent">
              <FileText className="h-5 w-5" aria-hidden="true" />
            </span>
            <h2 className="mt-6 text-balance text-2xl font-semibold tracking-tight text-ink sm:text-3xl">
              Interested in building scalable, enterprise-grade data platforms together?
            </h2>
            <p className="mt-4 max-w-lg text-base leading-relaxed text-ink-muted">
              Download my resume to learn more about my experience across data warehousing,
              cloud migrations, and AI-ready data infrastructure.
            </p>
            <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
              <ButtonLink
                href={`/${siteConfig.resumeFileName}`}
                external
                download={siteConfig.resumeFileName}
                icon={<Download className="h-4 w-4" aria-hidden="true" />}
              >
                Download Resume
              </ButtonLink>
              <ButtonLink href="#contact" variant="secondary">
                Contact Me
              </ButtonLink>
            </div>
          </div>
        </RevealOnScroll>
      </Container>
    </section>
  );
}
