"use client";

import { motion } from "framer-motion";
import type { ReactNode } from "react";

interface RevealOnScrollProps {
  children: ReactNode;
  delay?: number;
  y?: number;
  className?: string;
  once?: boolean;
}

/**
 * Wraps content in a subtle fade + slide-up reveal that triggers once the
 * element enters the viewport. Respects prefers-reduced-motion via the
 * `transition` duration only (Framer Motion honors OS-level settings for
 * whileInView by default when reduced motion is requested at the CSS layer).
 */
export function RevealOnScroll({
  children,
  delay = 0,
  y = 18,
  className,
  once = true,
}: RevealOnScrollProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once, margin: "-80px" }}
      transition={{ duration: 0.6, delay, ease: [0.21, 0.47, 0.32, 0.98] }}
      className={className}
    >
      {children}
    </motion.div>
  );
}
