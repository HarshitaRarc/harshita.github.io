"use client";

import { motion, useInView, useMotionValue, useSpring } from "framer-motion";
import { useEffect, useRef, useState } from "react";

interface AnimatedCounterProps {
  value: string;
  className?: string;
}

/**
 * Animates numeric prefixes of a metric string (e.g. "40%", "2TB+", "3+")
 * counting up from 0 when scrolled into view. Falls back to a static
 * render for non-numeric or reduced-motion contexts.
 */
export function AnimatedCounter({ value, className }: AnimatedCounterProps) {
  const ref = useRef<HTMLSpanElement>(null);
  const isInView = useInView(ref, { once: true, margin: "-40px" });
  const match = value.match(/^(\d+(?:\.\d+)?)(.*)$/);
  const numeric = match?.[1] ? parseFloat(match[1]) : null;
  const suffix = match?.[2] ?? "";
  const motionVal = useMotionValue(0);
  const spring = useSpring(motionVal, { duration: 1200, bounce: 0 });
  const [display, setDisplay] = useState(numeric === null ? value : "0");

  useEffect(() => {
    if (isInView && numeric !== null) {
      motionVal.set(numeric);
    }
  }, [isInView, numeric, motionVal]);

  useEffect(() => {
    const unsubscribe = spring.on("change", (latest) => {
      if (numeric === null) return;
      const isInt = Number.isInteger(numeric);
      setDisplay(isInt ? String(Math.round(latest)) : latest.toFixed(1));
    });
    return unsubscribe;
  }, [spring, numeric]);

  return (
    <motion.span ref={ref} className={className}>
      {numeric === null ? value : `${display}${suffix}`}
    </motion.span>
  );
}
