import { cn } from "@/lib/utils";
import Link from "next/link";
import type { AnchorHTMLAttributes, ButtonHTMLAttributes, ReactNode } from "react";

const baseStyles =
  "inline-flex items-center justify-center gap-2 rounded-lg text-sm font-semibold transition-all duration-200 focus-visible:outline-none disabled:pointer-events-none disabled:opacity-50 px-5 py-3 active:scale-[0.98]";

const variants = {
  primary:
    "bg-accent text-base-950 hover:bg-accent-soft shadow-[0_0_0_1px_rgba(59,167,255,0.4),0_8px_24px_-8px_rgba(59,167,255,0.55)] hover:shadow-[0_0_0_1px_rgba(127,200,255,0.5),0_10px_30px_-8px_rgba(127,200,255,0.6)]",
  secondary:
    "border border-white/15 bg-white/[0.03] text-ink hover:bg-white/[0.07] hover:border-white/25",
  ghost: "text-ink-muted hover:text-ink hover:bg-white/[0.05]",
};

type Variant = keyof typeof variants;

interface ButtonLinkProps extends AnchorHTMLAttributes<HTMLAnchorElement> {
  variant?: Variant;
  icon?: ReactNode;
  href: string;
  external?: boolean;
}

export function ButtonLink({
  variant = "primary",
  icon,
  href,
  external,
  className,
  children,
  ...props
}: ButtonLinkProps) {
  const classes = cn(baseStyles, variants[variant], className);

  if (external) {
    return (
      <a href={href} className={classes} target="_blank" rel="noopener noreferrer" {...props}>
        {children}
        {icon}
      </a>
    );
  }

  return (
    <Link href={href} className={classes} {...props}>
      {children}
      {icon}
    </Link>
  );
}

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  icon?: ReactNode;
}

export function Button({ variant = "primary", icon, className, children, ...props }: ButtonProps) {
  return (
    <button className={cn(baseStyles, variants[variant], className)} {...props}>
      {children}
      {icon}
    </button>
  );
}
