import type {
  Certification,
  EducationEntry,
  ExperienceRole,
  HeroMetric,
  NavLink,
  Project,
  Publication,
  SkillCategory,
  SocialLink,
} from "@/types";
import { siteConfig } from "@/lib/site-config";

/**
 * Every fact below is sourced directly from Ponkala Harshita Gayathri's
 * resume. No companies, metrics, certifications, or technologies have been
 * invented — figures like "40%", "150GB", "2TB+" etc. are quoted as written.
 */

export const navLinks: NavLink[] = [
  { label: "About", href: "#about" },
  { label: "Experience", href: "#experience" },
  { label: "Skills", href: "#skills" },
  { label: "Projects", href: "#projects" },
  { label: "Certifications", href: "#certifications" },
  { label: "Education", href: "#education" },
  { label: "Contact", href: "#contact" },
];

export const socialLinks: SocialLink[] = [
  { label: "Email", href: `mailto:${siteConfig.email}`, icon: "mail" },
  { label: "LinkedIn", href: siteConfig.linkedinUrl, icon: "linkedin" },
  { label: "GitHub", href: siteConfig.githubUrl, icon: "github" },
];

export const heroMetrics: HeroMetric[] = [
  {
    label: "Enterprise experience",
    value: "3+",
    suffix: "yrs",
    description: "Architecting production-grade data platforms",
  },
  {
    label: "Data under management",
    value: "2TB+",
    description: "Billions of records validated across a Snowflake migration",
  },
  {
    label: "Report turnaround",
    value: "40%",
    description: "Faster ad-hoc reporting after a warehouse re-architecture",
  },
  {
    label: "Incident resolution",
    value: "50%",
    description: "Reduction in MTTR from real-time monitoring tooling",
  },
];

export const experience: ExperienceRole[] = [
  {
    id: "fidelity-data-engineer",
    company: "Fidelity Investments",
    role: "Data Engineer",
    location: "Bengaluru, India",
    startDate: "Sep 2023",
    endDate: "Present",
    summary:
      "Owns core data warehouse subject areas end-to-end — from ambiguous requirements to long-term data models — partnering with senior engineers, stakeholders, and data science teams to drive data quality, reliability, and efficiency across the stack.",
    highlights: [
      {
        title: "Client Account Data Warehouse Modernization",
        challenge:
          "The existing client account and transaction data subject area had no mechanism to track historical changes, creating a growing risk to reporting accuracy.",
        solution:
          "Owned the subject area end-to-end and re-architected it around SCD-based dimensional models, using window-function and recursive-CTE reconciliation logic designed in partnership with senior engineers and business stakeholders.",
        impact: [
          "Cut ad-hoc report turnaround time by 40%",
          "Became the team's primary point of contact for the subject area",
          "Established a reusable data foundation for downstream analytics and AI/ML use cases",
        ],
        technologies: ["SQL", "Window Functions", "Recursive CTEs", "Dimensional Modeling", "SCD"],
      },
      {
        title: "Data Foundation & Quality Layer for Fraud Risk Scoring",
        challenge:
          "A fraud/risk scoring model used by the data science team needed reliable, production-grade feature data with ambiguous, evolving requirements.",
        solution:
          "Designed feature pipelines and automated data-quality checks — schema validation, null/threshold monitoring, and reconciliation — and built a lightweight Python-based triage tool that flagged and quarantined bad data before it reached the model.",
        impact: [
          "Reduced downstream model errors and manual investigation effort",
          "Helped establish data quality standards adopted across the team",
          "Translated ambiguous feature requirements into production-grade pipelines",
        ],
        technologies: ["Python", "Data Quality Automation", "Schema Validation", "Reconciliation"],
      },
      {
        title: "DMAPS — Data Management & Performance Suite",
        challenge:
          "Engineering and leadership lacked real-time visibility into system health across ~300+ production databases generating weekly DBA telemetry.",
        solution:
          "Architected core components of DMAPS, an Airflow-orchestrated pipeline consolidating ~150GB of weekly DBA telemetry from 300+ production databases into a single enterprise warehouse, with 10+ audit-ready reports including a Performance Dashboard, Trend Analyzer, and Anomaly Detection.",
        impact: [
          "Reduced mean time to resolution (MTTR) by 50% during production incidents",
          "Became a standard tool adopted across the DBA and engineering organization",
          "Delivered real-time visibility into system health for engineering and leadership",
        ],
        technologies: ["Apache Airflow", "Python", "SQL", "Data Orchestration", "Monitoring"],
      },
      {
        title: "Spark-Based Data Validation Framework (Oracle → Snowflake Migration)",
        challenge:
          "An on-prem Oracle-to-Snowflake migration spanning 20 tables — some with up to 2 billion records each, 2TB+ total — required certified data integrity before cutover.",
        solution:
          "Built a Spark-based validation framework to certify data integrity across the migration, then generalized it into a reusable, database-agnostic tool with PostgreSQL support, extending its use well beyond the original project.",
        impact: [
          "Certified data integrity across 20 tables, 2TB+ and billions of records",
          "Generalized into a reusable, database-agnostic validation tool",
          "Aligned feature delivery SLAs with senior engineers, stakeholders, and data science teams",
        ],
        technologies: ["Apache Spark", "Oracle", "Snowflake", "PostgreSQL", "Data Validation"],
      },
    ],
  },
  {
    id: "fidelity-intern",
    company: "Fidelity Investments",
    role: "Data Engineer Intern",
    location: "Bengaluru, India",
    startDate: "Feb 2023",
    endDate: "Jul 2023",
    summary:
      "Built an automated analytics framework and optimized ETL pipelines feeding enterprise reporting dashboards.",
    highlights: [
      {
        title: "Automated Audit Analytics Framework",
        challenge:
          "300GB+ of audit data was scattered across 40+ business units with no centralized, reliable path to reporting.",
        solution:
          "Engineered an automated analytics framework that ingested, cleaned, and centralized the data, writing SQL/Python transformations to improve reporting accuracy, and built and optimized ETL pipelines feeding Power BI dashboards.",
        impact: [
          "Centralized 300GB+ of audit data from 40+ business units",
          "Saved 50+ hours per quarter through automation",
          "Improved reporting accuracy across business units",
        ],
        technologies: ["SQL", "Python", "ETL", "Power BI"],
      },
    ],
  },
];

export const skillCategories: SkillCategory[] = [
  {
    id: "languages",
    title: "Languages & Querying",
    description: "Core programming and query languages for data systems.",
    icon: "code",
    skills: ["Python", "Java", "SQL", "Window Functions", "Recursive CTEs"],
  },
  {
    id: "data-engineering",
    title: "Data Engineering & ETL",
    description: "Pipeline design, orchestration, and performance optimization.",
    icon: "workflow",
    skills: ["ETL/ELT Pipeline Design", "Apache Spark", "Airflow Orchestration", "Data Pipeline Optimization"],
  },
  {
    id: "cloud-databases",
    title: "Databases & Cloud",
    description: "Cloud infrastructure and database platforms at enterprise scale.",
    icon: "cloud",
    skills: ["AWS (Certified Solutions Architect)", "Oracle", "Snowflake", "PostgreSQL", "Database Administration"],
  },
  {
    id: "reporting-governance",
    title: "Reporting & Delivery",
    description: "Turning pipelines into trusted, governed, production reporting.",
    icon: "shield",
    skills: ["Power BI", "Data Governance & Security", "Incident Management", "Stakeholder Engagement"],
  },
];

export const projects: Project[] = [
  {
    id: "enterprise-ai-platform-assistant",
    title: "Enterprise AI Platform Assistant",
    tagline: "RAG-based knowledge retrieval for 1,500+ engineers",
    challenge:
      "Engineering teams across DevOps, databases, Kubernetes, CI/CD, Secret Vault, monitoring, and platform operations relied on scattered documentation, creating repetitive support requests and slow self-service resolution.",
    solution:
      "Architected and delivered a production-grade Retrieval-Augmented Generation (RAG) platform serving 1,500+ engineers, enabling conversational access to enterprise knowledge with a hybrid retrieval engine that combines semantic vector search, metadata-based filtering, and reranking to maximize answer accuracy while minimizing LLM hallucinations.",
    architecture: [
      "Automated ingestion pipeline processing 5K+ Confluence pages, PDFs, Word documents, architecture diagrams, images, and runbooks via OCR, semantic chunking, metadata extraction, and embedding generation for continuous indexing",
      "Hybrid retrieval engine combining semantic vector search with metadata-based filtering and reranking",
      "Asynchronous indexing and retrieval pipelines with embedding caching and incremental document synchronization",
      "Conversation memory, source attribution, document citation, and role-based access controls",
    ],
    impact: [
      "95%+ answer accuracy while minimizing LLM hallucinations",
      "70% reduction in query latency, maintaining sub-2-second response times",
      "65% reduction in repetitive platform support requests",
      "500+ engineering hours saved annually through self-service resolution",
    ],
    technologies: [
      "Python",
      "FastAPI",
      "LangChain",
      "Enterprise LLM",
      "Vector Database",
      "Confluence API",
      "Docker",
      "Kubernetes",
      "Redis",
    ],
    icon: "ai",
  },
  {
    id: "warehouse-modernization",
    title: "Client Account Data Warehouse Modernization",
    tagline: "Re-architecting a core subject area for historical accuracy",
    challenge:
      "The client account and transaction data warehouse had no mechanism to track historical changes, posing a growing risk to reporting accuracy across the business.",
    solution:
      "Owned the subject area end-to-end and re-architected it around SCD-based dimensional models, designing the schema and validation approach in partnership with senior engineers and business stakeholders.",
    architecture: [
      "SCD-based dimensional modeling for historical tracking",
      "Window-function and recursive-CTE reconciliation logic",
      "Reusable data foundation for downstream analytics and AI/ML use cases",
    ],
    impact: ["40% faster ad-hoc report turnaround", "Primary point of contact for the subject area"],
    technologies: ["SQL", "Dimensional Modeling", "SCD", "Window Functions", "Recursive CTEs"],
    icon: "warehouse",
  },
  {
    id: "spark-validation-framework",
    title: "Spark-Based Data Validation Framework",
    tagline: "Certifying data integrity for an Oracle → Snowflake migration",
    challenge:
      "An on-prem Oracle-to-Snowflake migration spanning 20 tables — up to 2 billion records each, 2TB+ total — needed certified data integrity before cutover.",
    solution:
      "Built a Spark-based validation framework to certify integrity across the migration, then generalized it into a reusable, database-agnostic tool with PostgreSQL support.",
    architecture: [
      "Apache Spark validation jobs across 20 tables, 2TB+ total",
      "Database-agnostic design generalized beyond Oracle/Snowflake",
      "PostgreSQL support added for reuse across future migrations",
    ],
    impact: ["Certified integrity across 2 billion+ record tables", "Reusable tool adopted beyond the original migration"],
    technologies: ["Apache Spark", "Oracle", "Snowflake", "PostgreSQL"],
    icon: "spark",
  },
  {
    id: "dmaps",
    title: "DMAPS — Data Management & Performance Suite",
    tagline: "Enterprise telemetry and monitoring at scale",
    challenge:
      "Engineering and leadership had no real-time visibility into system health across 300+ production databases generating weekly DBA telemetry.",
    solution:
      "Architected core components of DMAPS, an Airflow-orchestrated pipeline consolidating ~150GB of weekly telemetry into a single enterprise warehouse, with 10+ audit-ready reports.",
    architecture: [
      "Airflow-orchestrated ingestion from 300+ production databases",
      "~150GB weekly telemetry consolidated into one enterprise warehouse",
      "10+ reports: Performance Dashboard, Trend Analyzer, Anomaly Detection",
    ],
    impact: ["50% reduction in mean time to resolution (MTTR)", "Adopted as a standard tool across DBA & engineering"],
    technologies: ["Apache Airflow", "Python", "SQL"],
    icon: "suite",
  },
];

export const certifications: Certification[] = [
  {
    id: "aws-csa",
    title: "AWS Certified Solutions Architect – Associate",
    issuer: "Amazon Web Services",
    description:
      "Endorsement for skills in AWS cloud architecture, cloud data, and cloud infrastructure.",
    credentialUrl: siteConfig.credlyUrl,
  },
];

export const education: EducationEntry[] = [
  {
    institution: "RV College of Engineering",
    degree: "Bachelor of Engineering",
    field: "Electronics and Communication",
    startDate: "Aug 2019",
    endDate: "May 2023",
    gpa: "8.9 CGPA",
    coursework: [
      "Data Warehousing & ETL",
      "Distributed Systems (Spark, Hadoop)",
      "Database Management Systems",
      "Cloud Computing",
    ],
  },
];

export const publication: Publication = {
  title: "Speech Emotion Recognition and Voice Conversion using the MelGAN Model",
  venue: "MCMI / International Journal of Management, IT & Engineering (IJMIT)",
  url: siteConfig.publicationUrl,
};
