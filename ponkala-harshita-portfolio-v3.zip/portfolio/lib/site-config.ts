/**
 * Central site configuration. Update `siteUrl` before deploying so that
 * metadata, Open Graph tags, and the sitemap resolve to the correct domain.
 */
export const siteConfig = {
  name: "Ponkala Harshita Gayathri",
  role: "Data Engineer",
  headline: "Data Engineer | AWS | Snowflake | Apache Spark | Python | SQL",
  tagline:
    "Building scalable enterprise data platforms, modern ETL pipelines, and AI-ready data infrastructure.",
  description:
    "Portfolio of Ponkala Harshita Gayathri, a Data Engineer specializing in enterprise data warehousing, Apache Spark, Snowflake, AWS, and AI/ML-ready data pipelines at Fidelity Investments.",
  location: "Bengaluru, India",
  email: "ponkalaharshitagayathri@gmail.com",
  // NOTE: the resume's "LinkedIn Profile" hyperlink resolves to a generic
  // linkedin.com URL rather than a personal profile slug. Replace this with
  // the direct profile URL (e.g. https://linkedin.com/in/...) when available.
  linkedinUrl: "https://www.linkedin.com/",
  // No GitHub URL is present on the resume — placeholder until provided.
  githubUrl: "https://github.com/",
  credlyUrl: "https://www.credly.com/badges/0b502212-66d9-471b-bbf5-7217a9f596f6",
  publicationUrl: "https://ijmit.org/Photo/IJMIT20240284R1_289R2.pdf",
  // Update to the production domain before deploying.
  siteUrl: "https://ponkalaharshitagayathri.dev",
  resumeFileName: "Ponkala_Harshita_Gayathri_Resume.pdf",
};
