"use client";

import { useEffect, useState } from "react";

/**
 * Tracks which section is currently most visible in the viewport so the
 * navbar can highlight the corresponding link (scrollspy). Falls back
 * gracefully to `null` on the server and before hydration.
 */
export function useActiveSection(sectionIds: string[], options?: { offset?: number }) {
  const [activeId, setActiveId] = useState<string | null>(null);

  useEffect(() => {
    const offset = options?.offset ?? 120;
    const elements = sectionIds
      .map((id) => document.getElementById(id))
      .filter((el): el is HTMLElement => Boolean(el));

    if (elements.length === 0) return;

    const handleScroll = () => {
      const scrollPos = window.scrollY + offset;
      let current: string | null = null;

      for (const el of elements) {
        if (el.offsetTop <= scrollPos) {
          current = el.id;
        }
      }

      // Special-case: near the bottom of the page, force the last section active.
      const atBottom =
        window.innerHeight + window.scrollY >= document.documentElement.scrollHeight - 4;
      if (atBottom && elements.length > 0) {
        current = elements[elements.length - 1]?.id ?? current;
      }

      setActiveId(current);
    };

    handleScroll();
    window.addEventListener("scroll", handleScroll, { passive: true });
    window.addEventListener("resize", handleScroll);
    return () => {
      window.removeEventListener("scroll", handleScroll);
      window.removeEventListener("resize", handleScroll);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sectionIds.join(",")]);

  return activeId;
}
