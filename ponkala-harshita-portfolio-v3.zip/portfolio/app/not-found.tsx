import { ArrowLeft } from "lucide-react";
import { Container } from "@/components/ui/Container";
import { ButtonLink } from "@/components/ui/Button";

export default function NotFound() {
  return (
    <section className="flex min-h-[70vh] items-center py-24">
      <Container className="text-center">
        <p className="font-mono text-sm text-accent-soft">404</p>
        <h1 className="mt-3 text-3xl font-semibold text-ink">Page not found</h1>
        <p className="mx-auto mt-3 max-w-md text-ink-muted">
          The page you&rsquo;re looking for doesn&rsquo;t exist or has moved.
        </p>
        <div className="mt-8">
          <ButtonLink href="/" icon={<ArrowLeft className="h-4 w-4" aria-hidden="true" />}>
            Back to home
          </ButtonLink>
        </div>
      </Container>
    </section>
  );
}
