import type { Metadata } from "next";
import "./globals.css";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { BackToTop } from "@/components/ui/BackToTop";
import { siteConfig } from "@/lib/site-config";

export const metadata: Metadata = {
  metadataBase: new URL(siteConfig.siteUrl),
  title: {
    default: `${siteConfig.name} — ${siteConfig.headline}`,
    template: `%s | ${siteConfig.name}`,
  },
  description: siteConfig.description,
  keywords: [
    "Data Engineer",
    "AWS",
    "Snowflake",
    "Apache Spark",
    "Python",
    "SQL",
    "ETL",
    "Data Warehousing",
    "Airflow",
    "Cloud Data Platform",
    "Ponkala Harshita Gayathri",
  ],
  authors: [{ name: siteConfig.name }],
  creator: siteConfig.name,
  applicationName: `${siteConfig.name} Portfolio`,
  robots: {
    index: true,
    follow: true,
    googleBot: { index: true, follow: true },
  },
  openGraph: {
    type: "profile",
    url: siteConfig.siteUrl,
    title: `${siteConfig.name} — ${siteConfig.headline}`,
    description: siteConfig.description,
    siteName: `${siteConfig.name} Portfolio`,
    images: [{ url: "/og-image.svg", width: 1200, height: 630, alt: siteConfig.name }],
  },
  twitter: {
    card: "summary_large_image",
    title: `${siteConfig.name} — ${siteConfig.headline}`,
    description: siteConfig.description,
    images: ["/og-image.svg"],
  },
  icons: {
    icon: "/favicon.svg",
  },
};

export const viewport = {
  themeColor: "#05070a",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Person",
    name: siteConfig.name,
    jobTitle: siteConfig.role,
    description: siteConfig.description,
    email: siteConfig.email,
    address: {
      "@type": "PostalAddress",
      addressLocality: siteConfig.location,
    },
    url: siteConfig.siteUrl,
    sameAs: [siteConfig.linkedinUrl].filter(Boolean),
    knowsAbout: [
      "Data Engineering",
      "AWS",
      "Snowflake",
      "Apache Spark",
      "Python",
      "SQL",
      "ETL",
      "Data Warehousing",
      "Apache Airflow",
    ],
  };

  return (
    <html lang="en">
      <body className="min-h-screen bg-base-950 font-sans text-ink antialiased">
        <a href="#main-content" className="skip-link">
          Skip to main content
        </a>
        <script
          type="application/ld+json"
          // eslint-disable-next-line react/no-danger
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
        />
        <Navbar />
        <main id="main-content">{children}</main>
        <Footer />
        <BackToTop />
      </body>
    </html>
  );
}
